// Array para armazenar os lembretes temporariamente
let lembretes = [];

// Função para renderizar lembretes na tela
function renderizarLembretes() {
    const listElement = document.getElementById('lembretes-list');
    listElement.innerHTML = ''; // Limpar a lista antes de renderizar

    lembretes.sort((a, b) => a.timestamp - b.timestamp); // Ordenar lembretes por timestamp

    lembretes.forEach((lembrete) => {
        const listItem = document.createElement('li');
        listItem.className = 'list-group-item';

        // Formatar a data no formato brasileiro (dd/mm/yyyy)
        const dataFormatada = new Date(lembrete.timestamp);
        const dia = String(dataFormatada.getDate()).padStart(2, '0');
        const mes = String(dataFormatada.getMonth() + 1).padStart(2, '0');
        const ano = dataFormatada.getFullYear();
        const dataBrasil = `${dia}/${mes}/${ano}`;

        listItem.innerHTML = `
            <div>
                <strong>${lembrete.nome}</strong><br>
                Data: ${dataBrasil}
            </div>
            <button class="btn btn-danger btn-sm" onclick="excluirLembrete(${lembrete.id})">Excluir</button>
        `;

        listElement.appendChild(listItem);
    });
}

// Função para adicionar lembretes
function adicionarLembrete(lembrete) {
    lembretes.push(lembrete);
    renderizarLembretes();  // Atualizar a lista
}

// Função para excluir um lembrete
function excluirLembrete(id) {
    lembretes = lembretes.filter(lembrete => lembrete.id !== id);
    renderizarLembretes();  // Atualizar a lista
}

// Função para limpar os campos do formulário
function limparCampos() {
    document.getElementById('nome').value = '';
    document.getElementById('data').value = '';
}

// Evento de submissão do formulário
document.getElementById('formLembrete').addEventListener('submit', function(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value;
    const data = document.getElementById('data').value;

    if (nome && data) {
        // Criar o timestamp com a data correta
        const dataFormatada = new Date(data + 'T00:00:00-03:00'); // Ajuste para horário de Brasília (GMT-3)

        const lembrete = {
            id: Date.now(), // Usando timestamp como ID único
            nome: nome,
            data: data,
            timestamp: dataFormatada.getTime() // Criando o timestamp com a data correta
        };

        adicionarLembrete(lembrete);
        limparCampos();
    } else {
        alert("Por favor, preencha todos os campos corretamente.");
    }
});

// Inicializar a renderização dos lembretes
renderizarLembretes();
