# testeDTI
Projeto de Lembretes
Este é um projeto desenvolvido como parte de um teste prático para o processo seletivo da DTI Digital. A aplicação é simples, mas funcional, oferecendo uma interface amigável para criação e gerenciamento de lembretes.

📝 Descrição
O sistema permite:
Adicionar lembretes com descrição e data.
Excluir lembretes com um clique.
Exibir os lembretes em ordem cronológica.

🛠 Código Construído
HTML5: Estrutura da página.
CSS3: Estilização moderna e responsiva.
JavaScript: Manipulação de dados, validação e interação com o DOM.
Bootstrap (CDN): Complemento para estilização rápida.

🔮 Premissas Assumidas
Apenas datas futuras são válidas.
O projeto é exclusivamente local, sem back-end.
A lista de lembretes é automaticamente ordenada.

📐 Decisões de Projeto
Simplicidade: Uso de JavaScript puro, evitando dependências externas.
Validação no front-end: Garantir usabilidade ao validar entradas no navegador.
Ordenação dinâmica: Inserção automática dos lembretes na ordem correta.

🚀 Como Rodar
Abra o projeto no Visual Studio Code.
Use a extensão Live Server.
Clique com o botão direito no arquivo index.html e selecione Open with Live Server.

📋 Funcionalidades
Validação automática: Apenas lembretes com datas futuras são permitidos.
Ordenação cronológica: Exibição automática dos lembretes em ordem de data.
Exclusão dinâmica: Remoção de lembretes sem recarregar a página.

💡 Melhorias Futuras
Implementar armazenamento com localStorage.
Adicionar notificações para eventos próximos.
Criar funcionalidade de edição de lembretes.

🖋 Créditos
Feito com dedicação e entusiasmo por Sarah Araujo. Agradeço à equipe da DTI Digital pela oportunidade de participar do processo seletivo.
